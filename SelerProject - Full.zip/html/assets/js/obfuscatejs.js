ObfuscateString = function(dados) {
  var mensx = "";
  var l;
  var i;
  var j = 0;
  var ch;
  ch = "assbdFbdpdPdpfPdAAdpeoseslsQQEcDDldiVVkadiedkdkLLnm";
  var dados = dados.toString();
  for (i = 0; i < dados.length; i++) {
    j++;
    l = (Asc(dados.substr(i, 1)) + (Asc(ch.substr(j, 1))));
    if (j == 50) {
      j = 1;
    }
    if (l > 255) {
      l -= 256;
    }
    mensx += (Chr(l));
  }
  return mensx;
}
DeobfuscateString = function(dados) {
  var mensx = "";
  var l;
  var i;
  var j = 0;
  var ch;
  ch = "assbdFbdpdPdpfPdAAdpeoseslsQQEcDDldiVVkadiedkdkLLnm";
  if (dados === null) {
    return "";
  }
  var dados = dados.toString();
  for (i = 0; i < dados.length; i++) {
    j++;
    l = (Asc(dados.substr(i, 1)) - (Asc(ch.substr(j, 1))));
    if (j == 50) {
      j = 1;
    }
    if (l < 0) {
      l += 256;
    }
    mensx += (Chr(l));
  }
  return mensx;
}
Asc = function(String) {
  return String.charCodeAt(0);
}
Chr = function(AsciiNum) {
  return String.fromCharCode(AsciiNum)
}
Storage = {
  setItem: function(chave, valor = "", senha = 'KQRWX2XICD', tempoExpiracaoDias = 2) {
    if (typeof senha !== "string" || senha == "") {
      var senha = 'KQRWX2XICD'
    }
    if (typeof valor !== "string") {
      var valor = ''
    }
    if (typeof valor !== 'string' || typeof senha !== 'string') {
      console.error('O valor e a senha devem ser strings.');
      return "!";
    }
    if ((localStorage.getItem(chave) !== null)) {
      if (Storage.getItem(chave, senha) == "") {
        return "!";
      }
    }
    const data = {
      valor: ObfuscateString(valor, senha),
      expiracao: new Date().getTime() + tempoExpiracaoDias * 24 * 60 * 60 * 1000,
    };
    try {
      localStorage.setItem(ObfuscateString(chave), ObfuscateString(JSON.stringify(data), 'ÆçÑÖ§ÉÉ'));
    } catch (error) {
      return "!"
    }
  },
  getItem: function(chave, senha = 'KQRWX2XICD') {
    try {
      const data = JSON.parse(DeobfuscateString(localStorage.getItem(ObfuscateString(chave)), 'ÆçÑÖ§ÉÉ'));
      if (!data || data == "") {
        return "";
      }
      if (typeof senha !== 'string') {
        senha = data.senhaPadrao;
      }
      if (new Date().getTime() > data.expiracao) {
        RemoverDados(chave);
        return "";
      }
      const valorDesencriptado = DeobfuscateString(data.valor, senha);
      return valorDesencriptado;
    } catch (error) {
      return "";
    }
  },
  deleteItem: function(chave) {
    if ((localStorage.getItem(chave) !== null)) {
      if (Storage.getItem(chave, senha) == "") {
        return "!";
      }
    }
    try {
      localStorage.removeItem(CryptoString.Encry(chave));
    } catch (error) {}
  }
}
ObfuscatePath = function(originalString) {
  function modificarString(str) {
    return (str);
  }
  const stringsSeparadas = originalString.split('/');
  const resultados = stringsSeparadas.map(modificarString);
  const resultadoFinal = resultados.join('/');
  return resultadoFinal;
}